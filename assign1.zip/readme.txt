This directory contains two folders and two files

exe folder contains execuatable application
output folder contains screenshot of output
assign1.cs is program file


1.This program has been developed in c# language.
2.To run the program copy and paste code from assign1.cs to to https://repl.it/repls/TanGorgeousBuck
3.Run program with 8 initial block input numbers and 8 goal block input numbers
